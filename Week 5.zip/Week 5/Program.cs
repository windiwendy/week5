﻿using System;
using System.Xml.Schema;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Channels;


namespace week_5
{
    class Program
    {
        static void Main(string[] args)
        {


            problemTwo();
            problemThree();
            problemFour();

        }


        static void problemTwo()
        {
            int[] num = new int[5];

            int total1;
            







            for (int i = 0; i < num.Length; i++)
            {

                
                    Console.WriteLine("Please enter 5 numbers to add up or press 999 to exit: ");
                    num[i] = Convert.ToInt32(Console.ReadLine());
                if(num[i] < 999)
                {
                    Console.WriteLine("__________   ");

                }
                else
                {
                    Environment.Exit(0);
                }

            }
                


                total1 = num.Sum();


                Console.WriteLine("the SUM is: " + total1);
                Console.WriteLine("___________________________________________");
                Console.WriteLine("");



           
            

            

        }

       static void problemThree()
        {

            int number;
            int fact;

            Console.WriteLine("Enter A number to find the Factoral : ");
            number = Convert.ToInt32(Console.ReadLine());

            fact = number;

            for (int i = number -1; i >= 1; i--)
            {
                fact = fact * i;

            }
            Console.WriteLine("Factoral is : " + fact );
            Console.WriteLine("________________________________________________");
            Console.WriteLine("");
        }


        static void problemFour()
        {
            int[] ranNum = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Random pick = new Random();
            int randomNum = pick.Next(1, ranNum.Length);
            int guess = 0;
            int a = 0;

            //just wanted to make sure the array was working 
            //for (int i = 0; i < ranNum.Length; i++)
           // {
                //Console.WriteLine(ranNum[i]);

           // }
            Console.WriteLine("Guess what number im thinking of from the list above: ");
            Console.WriteLine("You have 4 chances Good Luck!!");
            Console.WriteLine("--------------------------------------");

            //Console.WriteLine("random number is : " + randomNum);

            while ( a < 4)
            {
                Console.WriteLine("input your guess: ");
                guess = Convert.ToInt32(Console.ReadLine());
                a++;
                
                if (guess == randomNum)
                {
                    Console.WriteLine("YOU WON!!! ");
                    Console.WriteLine("________________________________________________");
                    Console.WriteLine(" ");
                    Console.WriteLine("random number is : " + randomNum);
                    Console.WriteLine("____*________*_______*_________*____________________");
                    Environment.Exit(0);
                }
                
            }
                
            
        
        

        }


    } 
}